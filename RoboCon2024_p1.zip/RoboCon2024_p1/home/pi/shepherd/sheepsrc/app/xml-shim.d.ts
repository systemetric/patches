declare module "*.xml" {
  const contents: string;
  export = contents;
}
