# Rules

You can download the official rules for 2020 [here](/docs/2019-10-17%20Chicken%20and%20egg%20game%20rules.pdf).

:::tip

If you are viewing this page on your brain box then please check the website for the lastest revision.

:::

## Arena

This is a bird’s-eye view of the arena labelled with dimensions and wall marker numbers:

![Arena Diagram](./images/2020-arena-layout.png)
