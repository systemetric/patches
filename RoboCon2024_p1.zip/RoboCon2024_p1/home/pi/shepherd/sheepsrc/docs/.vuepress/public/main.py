import robot

R = robot.Robot()

print("Recovery complete!")
print("Please turn off your robot and unplug the USB stick.")
print("Then start the robot normally.")
