import robot

R = robot.Robot()
