---
title: Minibot Assembly
category: Hardware
position: 6
---
# Minibot Assembly

You can download instructions on how to make your minibot [here](/MiniBot%20assembly%20instruction%20manual%20.pdf).

<Embed :aspect-ratio="1/1.4142"><iframe width="100" height="141" src="/images/MiniBot%20assembly%20instruction%20manual%20.pdf"></iframe></Embed>
